"""Crypto news headline fetcher for Telegram operational briefings.

Uses public RSS/Atom feeds so the bot does not need another API key. The
fetcher is intentionally best-effort: network/feed failures are skipped and an
empty result simply suppresses the hourly news report.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from html import unescape
from urllib.parse import urlparse

import httpx

log = logging.getLogger(__name__)

_DEFAULT_FEEDS = [
    "https://www.coindesk.com/arc/outboundfeeds/rss/",
    "https://cointelegraph.com/rss",
    "https://decrypt.co/feed",
]

_URGENT_KEYWORDS = {
    "urgent": 8,
    "breaking": 8,
    "hack": 7,
    "exploit": 7,
    "breach": 7,
    "etf": 5,
    "lawsuit": 5,
    "charges": 5,
    "ban": 5,
    "approval": 5,
    "approved": 5,
    "rejected": 5,
    "liquidation": 4,
    "liquidations": 4,
    "crash": 6,
    "surge": 4,
    "plunge": 5,
    "bitcoin": 4,
    "btc": 4,
    "altcoin": 4,
    "altcoins": 4,
    "ethereum": 3,
    "eth": 3,
    "solana": 3,
    "sol": 3,
    "xrp": 3,
    "bnb": 3,
    "token": 2,
    "tokens": 2,
    "airdrop": 2,
    "defi": 2,
    "on-chain": 2,
    "stablecoin": 3,
    "tether": 4,
    "usdt": 4,
    "usdc": 3,
    "binance": 3,
    "coinbase": 3,
}

_BITCOIN_PATTERNS = [
    re.compile(r"\bbitcoin\b", re.I),
    re.compile(r"\bbtc\b", re.I),
]

_ALTCOIN_PATTERNS = [
    re.compile(r"\baltcoin(?:s)?\b", re.I),
    re.compile(r"\beth(?:ereum)?\b", re.I),
    re.compile(r"\bsol(?:ana)?\b", re.I),
    re.compile(r"\bxrp\b", re.I),
    re.compile(r"\bbnb\b", re.I),
    re.compile(r"\bdoge(?:coin)?\b", re.I),
    re.compile(r"\bada\b|\bcardano\b", re.I),
    re.compile(r"\bavax\b|\bavalanche\b", re.I),
    re.compile(r"\blink\b|\bchainlink\b", re.I),
    re.compile(r"\btoken(?:s)?\b", re.I),
    re.compile(r"\bmemecoin(?:s)?\b", re.I),
    re.compile(r"\bstablecoin(?:s)?\b", re.I),
    re.compile(r"\busdt\b|\busdc\b|\btether\b", re.I),
    re.compile(r"\bdefi\b|\bon-chain\b|\bairdrop\b", re.I),
]


@dataclass(frozen=True)
class CryptoNewsItem:
    title: str
    url: str
    source: str
    published_ts: float = 0.0
    urgent_score: float = 0.0


@dataclass(frozen=True)
class MarketNarrative:
    title: str
    bias: str
    explanation: str
    evidence: tuple[str, ...] = ()
    recommended_altcoins: tuple[str, ...] = ()
    recommendation_reason: str = ""
    source: str = "rule"
    urgency_score: float = 0.0
    confidence: float = 0.0


def default_crypto_news_feeds() -> list[str]:
    return list(_DEFAULT_FEEDS)


def _clean_text(value: str | None) -> str:
    text = unescape(str(value or ""))
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _source_from_url(url: str) -> str:
    host = urlparse(url).netloc.lower().removeprefix("www.")
    return host or "unknown"


def _published_ts(value: str | None) -> float:
    if not value:
        return 0.0
    try:
        return parsedate_to_datetime(value).timestamp()
    except Exception:
        return 0.0


def _child_text(node: ET.Element, names: tuple[str, ...]) -> str:
    for child in list(node):
        local = child.tag.rsplit("}", 1)[-1].lower()
        if local in names and child.text:
            return _clean_text(child.text)
    return ""


def _entry_link(node: ET.Element) -> str:
    for child in list(node):
        local = child.tag.rsplit("}", 1)[-1].lower()
        if local == "link":
            href = child.attrib.get("href")
            if href:
                return _clean_text(href)
            if child.text:
                return _clean_text(child.text)
    return ""


def _is_bitcoin_or_altcoin_relevant(title: str) -> bool:
    if any(pattern.search(title) for pattern in _BITCOIN_PATTERNS):
        return True
    return any(pattern.search(title) for pattern in _ALTCOIN_PATTERNS)


def _urgency_score(title: str, published_ts: float, now_ts: float) -> float:
    lower = title.lower()
    score = 0.0
    for keyword, weight in _URGENT_KEYWORDS.items():
        if re.search(rf"\b{re.escape(keyword)}\b", lower):
            score += weight
    if published_ts > 0:
        age_hours = max(0.0, (now_ts - published_ts) / 3600.0)
        score += max(0.0, 6.0 - min(age_hours, 12.0) * 0.5)
    return round(score, 3)


def parse_crypto_news_feed(xml_text: str, *, source_url: str = "", now_ts: float | None = None) -> list[CryptoNewsItem]:
    """Parse RSS/Atom XML into ranked candidate news items."""
    now = float(now_ts or time.time())
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return []

    source = _source_from_url(source_url)
    nodes: list[ET.Element] = []
    for node in root.iter():
        local = node.tag.rsplit("}", 1)[-1].lower()
        if local in {"item", "entry"}:
            nodes.append(node)

    items: list[CryptoNewsItem] = []
    for node in nodes:
        title = _child_text(node, ("title",))
        url = _child_text(node, ("link",)) or _entry_link(node)
        published_raw = _child_text(node, ("pubdate", "published", "updated"))
        if not title or not url:
            continue
        if not _is_bitcoin_or_altcoin_relevant(title):
            continue
        published = _published_ts(published_raw)
        items.append(
            CryptoNewsItem(
                title=title,
                url=url,
                source=source,
                published_ts=published,
                urgent_score=_urgency_score(title, published, now),
            )
        )
    return items


async def fetch_crypto_news_highlights(
    cfg: dict,
    *,
    limit: int = 5,
    timeout_s: float = 8.0,
) -> list[CryptoNewsItem]:
    """Fetch and rank urgent crypto headlines from configured RSS feeds."""
    news_cfg = cfg.get("telegram", {}) if isinstance(cfg, dict) else {}
    feeds = news_cfg.get("crypto_news_feeds") or _DEFAULT_FEEDS
    feeds = [str(feed).strip() for feed in feeds if str(feed).strip()]
    if not feeds or limit <= 0:
        return []

    async def _fetch(client: httpx.AsyncClient, feed_url: str) -> list[CryptoNewsItem]:
        try:
            resp = await client.get(feed_url, follow_redirects=True)
            if resp.status_code >= 400:
                log.debug("Crypto news feed failed %s: HTTP %s", feed_url, resp.status_code)
                return []
            return parse_crypto_news_feed(resp.text, source_url=feed_url)
        except Exception as exc:
            log.debug("Crypto news feed failed %s: %s", feed_url, exc)
            return []

    async with httpx.AsyncClient(timeout=timeout_s, headers={"User-Agent": "ninja-trader-news/1.0"}) as client:
        batches = await asyncio.gather(*(_fetch(client, feed) for feed in feeds), return_exceptions=True)

    deduped: dict[str, CryptoNewsItem] = {}
    for batch in batches:
        if isinstance(batch, Exception):
            continue
        for item in batch:
            key = re.sub(r"[^a-z0-9]+", " ", item.title.lower()).strip()
            if not key:
                continue
            prev = deduped.get(key)
            if prev is None or (item.urgent_score, item.published_ts) > (prev.urgent_score, prev.published_ts):
                deduped[key] = item

    ranked = sorted(
        deduped.values(),
        key=lambda item: (item.urgent_score, item.published_ts),
        reverse=True,
    )
    return ranked[:limit]


_ALTCOIN_RECOMMENDATIONS: dict[str, tuple[tuple[str, ...], str]] = {
    "BTC / ETF flow": (("ETH", "SOL", "BNB"), "BTC-led risk-on usually lifts the most liquid large-cap alt beta first."),
    "ETH / L1 rotation": (("ETH", "SOL", "NEAR", "SUI"), "L1 rotation narrative directly favors high-liquidity smart-contract chains."),
    "AI crypto": (("NEAR", "TAO", "RENDER", "FET"), "AI-linked headlines map directly to AI infrastructure and compute/token narratives."),
    "Privacy / self-custody": (("ZEC",), "Privacy narrative is most directly expressed through liquid privacy coins."),
    "DeFi / perp DEX": (("HYPE", "AAVE", "UNI"), "DeFi/perp DEX headlines favor protocol-fee and on-chain trading tokens."),
    "Stablecoin liquidity": (("ETH", "SOL", "BNB"), "Stablecoin liquidity expansion usually supports the most liquid settlement and DeFi chains."),
    "Regulation / legal": (("ETH", "SOL", "XRP", "BNB"), "Regulatory access headlines tend to affect major listed/liquid alts first."),
    "Security shock": ((), "No buy recommendation: security headlines are de-risking signals until contagion is clear."),
    "Liquidation / leverage": ((), "No buy recommendation: leverage headlines need confirmation after forced selling/squeezes cool down."),
    "Broad crypto rotation": (("ETH", "SOL", "NEAR"), "Broad alt rotation without a narrow theme favors liquid majors over thin narrative tokens."),
}


def _recommendations_for_bucket(bucket: str, bias: str) -> tuple[tuple[str, ...], str]:
    coins, reason = _ALTCOIN_RECOMMENDATIONS.get(bucket, _ALTCOIN_RECOMMENDATIONS["Broad crypto rotation"])
    if str(bias).lower() == "bearish":
        return (), f"No buy recommendation while the narrative bias is bearish. {reason}"
    return tuple(coins), reason


_NARRATIVE_BUCKETS: tuple[tuple[str, tuple[str, ...], str], ...] = (
    ("BTC / ETF flow", ("bitcoin", "btc", "etf", "ibit", "microstrategy", "treasury"), "BTC liquidity and institutional-flow headlines are driving market direction."),
    ("ETH / L1 rotation", ("ethereum", "eth", "solana", "sol", "near", "sui", "avax", "bnb", "xrp"), "Large-cap alt L1/L2 rotation is active; watch whether BTC dominance confirms risk-on breadth."),
    ("AI crypto", ("ai", "artificial intelligence", "near.ai", "bittensor", "tao", "render", "fet"), "AI-linked crypto assets are attracting attention from product and narrative catalysts."),
    ("Privacy / self-custody", ("zcash", "zec", "monero", "xmr", "privacy", "shielded", "surveillance"), "Financial privacy and self-custody are being repriced as a separate market theme."),
    ("DeFi / perp DEX", ("hyperliquid", "hype", "defi", "perp", "perpetual", "dex", "on-chain", "airdrop"), "On-chain trading, perp DEX volume, and protocol-fee narratives are leading DeFi attention."),
    ("Stablecoin liquidity", ("stablecoin", "usdt", "usdc", "tether", "circle", "yield-bearing"), "Stablecoin supply, issuer news, or payment rails may be changing available crypto liquidity."),
    ("Regulation / legal", ("sec", "cftc", "lawsuit", "charges", "ban", "approved", "approval", "rejected", "congress", "regulation"), "Regulatory headlines can reprice access, listings, and institutional risk appetite."),
    ("Security shock", ("hack", "exploit", "breach", "stolen", "drain", "phishing"), "Security incidents can force de-risking, liquidity moves, and exchange-specific pressure."),
    ("Liquidation / leverage", ("liquidation", "liquidations", "funding", "open interest", "short squeeze", "long squeeze"), "Leverage positioning is part of the move; reversals can be fast if OI unwinds."),
)


def _headline_text(item: CryptoNewsItem) -> str:
    return str(getattr(item, "title", "") or "").strip()


def _bucket_for_title(title: str) -> tuple[str, str]:
    lower = title.lower()
    best_name = "Broad crypto rotation"
    best_desc = "Crypto-specific headlines are clustered, but no single specialized theme dominates yet."
    best_hits = 0
    for name, keywords, desc in _NARRATIVE_BUCKETS:
        hits = sum(1 for keyword in keywords if keyword in lower)
        if hits > best_hits:
            best_name = name
            best_desc = desc
            best_hits = hits
    return best_name, best_desc


def _bias_for_titles(titles: list[str]) -> str:
    text = " ".join(titles).lower()
    bullish = sum(1 for word in ("surge", "rally", "approval", "approved", "inflow", "record", "ath", "launch", "accumulat") if word in text)
    bearish = sum(1 for word in ("hack", "exploit", "charges", "ban", "outflow", "crash", "plunge", "rejected", "liquidation") if word in text)
    if bullish > bearish:
        return "bullish"
    if bearish > bullish:
        return "bearish"
    return "mixed"


def build_rule_based_market_narratives(items: list[CryptoNewsItem], *, limit: int = 5) -> list[MarketNarrative]:
    """Group headlines into readable market narratives without an LLM."""
    buckets: dict[str, dict] = {}
    for item in items:
        title = _headline_text(item)
        if not title:
            continue
        bucket, desc = _bucket_for_title(title)
        entry = buckets.setdefault(bucket, {"desc": desc, "items": [], "score": 0.0})
        entry["items"].append(item)
        entry["score"] += float(getattr(item, "urgent_score", 0.0) or 0.0)

    narratives: list[MarketNarrative] = []
    for bucket, entry in buckets.items():
        bucket_items = sorted(
            entry["items"],
            key=lambda item: (float(getattr(item, "urgent_score", 0.0) or 0.0), float(getattr(item, "published_ts", 0.0) or 0.0)),
            reverse=True,
        )
        titles = [_headline_text(item) for item in bucket_items if _headline_text(item)]
        sources = []
        for item in bucket_items:
            source = str(getattr(item, "source", "") or "").strip()
            if source and source not in sources:
                sources.append(source)
        evidence = tuple(titles[:3])
        bias = _bias_for_titles(titles)
        coins, rec_reason = _recommendations_for_bucket(bucket, bias)
        confidence = min(0.95, 0.35 + 0.15 * len(evidence) + min(float(entry["score"]), 30.0) / 100.0)
        narratives.append(
            MarketNarrative(
                title=bucket,
                bias=bias,
                explanation=f"{entry['desc']} Evidence count={len(titles)}; sources={', '.join(sources[:3]) or 'unknown'}.",
                evidence=evidence,
                recommended_altcoins=coins,
                recommendation_reason=rec_reason,
                source="rule",
                urgency_score=round(float(entry["score"]), 3),
                confidence=round(confidence, 3),
            )
        )

    return sorted(narratives, key=lambda narrative: (narrative.urgency_score, narrative.confidence), reverse=True)[:limit]


_PUBLIC_LLM_PROVIDERS: dict[str, dict] = {
    "openrouter": {
        "api_url": "https://openrouter.ai/api/v1/chat/completions",
        "model": "openrouter/free",
        "api_key_env": ("OPENROUTER_API_KEY",),
    },
    "groq": {
        "api_url": "https://api.groq.com/openai/v1/chat/completions",
        "model": "llama-3.3-70b-versatile",
        "api_key_env": ("GROQ_API_KEY",),
    },
    "huggingface": {
        "api_url": "https://router.huggingface.co/v1/chat/completions",
        "model": "openai/gpt-oss-120b",
        "api_key_env": ("HF_TOKEN", "HUGGINGFACEHUB_API_TOKEN"),
    },
    "gemini": {
        "api_url": "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
        "model": "gemini-2.5-flash",
        "api_key_env": ("GEMINI_API_KEY", "GOOGLE_API_KEY"),
    },
    "openai": {
        "api_url": "https://api.openai.com/v1/chat/completions",
        "model": "gpt-4.1-mini",
        "api_key_env": ("OPENAI_API_KEY",),
    },
}


def _env_first(names: tuple[str, ...] | list[str] | str) -> str:
    if isinstance(names, str):
        names = (names,)
    for name in names:
        value = os.getenv(str(name).strip())
        if value:
            return value.strip()
    return ""


def _llm_provider_candidates(cfg: dict) -> list[dict]:
    tg = cfg.get("telegram", {}) if isinstance(cfg, dict) else {}
    if not bool(tg.get("crypto_news_llm_enabled", False)):
        return []

    timeout = float(tg.get("crypto_news_llm_timeout_seconds", 12.0) or 12.0)
    provider_mode = str(tg.get("crypto_news_llm_provider", "auto") or "auto").strip().lower()
    provider_overrides = tg.get("crypto_news_llm_providers", {}) or {}
    order = ["gemini", "openrouter", "groq", "huggingface", "openai"]
    if provider_mode not in {"", "auto"}:
        order = [provider_mode]

    candidates: list[dict] = []
    custom_api_url = str(tg.get("crypto_news_llm_api_url", "") or "").strip()
    custom_model = str(tg.get("crypto_news_llm_model", "") or "").strip()
    custom_key = str(
        _env_first(str(tg.get("crypto_news_llm_api_key_env", "") or ""))
        or tg.get("crypto_news_llm_api_key", "")
        or ""
    ).strip()
    if provider_mode in {"custom", "auto"} and custom_api_url and custom_model and custom_key:
        candidates.append(
            {
                "provider": "custom",
                "api_url": custom_api_url,
                "model": custom_model,
                "api_key": custom_key,
                "timeout": timeout,
            }
        )

    for provider in order:
        if provider == "custom":
            continue
        base = dict(_PUBLIC_LLM_PROVIDERS.get(provider, {}))
        if not base:
            continue
        override = dict(provider_overrides.get(provider, {}) or {}) if isinstance(provider_overrides, dict) else {}
        merged = {**base, **override}
        env_names = merged.get("api_key_env") or base.get("api_key_env") or ()
        api_key = str(_env_first(env_names) or merged.get("api_key", "") or "").strip()
        api_url = str(merged.get("api_url", "") or "").strip()
        model = str(merged.get("model", "") or "").strip()
        if not api_key or not api_url or not model:
            continue
        candidates.append(
            {
                "provider": provider,
                "api_url": api_url,
                "model": model,
                "api_key": api_key,
                "timeout": timeout,
            }
        )
    return candidates


def _llm_prompt(items: list[CryptoNewsItem], *, limit: int) -> list[dict]:
    rows = []
    for idx, item in enumerate(items[:12], start=1):
        rows.append(
            {
                "id": idx,
                "title": _headline_text(item),
                "source": str(getattr(item, "source", "unknown") or "unknown"),
                "urgency_score": float(getattr(item, "urgent_score", 0.0) or 0.0),
            }
        )
    return [
        {
            "role": "system",
            "content": (
                "You are a crypto market analyst. Cluster headlines into market hot narratives, "
                "not generic news summaries. Be precise, avoid price predictions, and return JSON only."
            ),
        },
        {
            "role": "user",
            "content": (
                f"Build up to {limit} hot crypto market narratives from these headlines. "
                "Return a JSON array. Each object must have: title, bias "
                "(bullish|bearish|mixed), explanation (max 32 words), evidence_ids "
                "(array of headline ids), recommended_altcoins (0-5 liquid altcoin tickers to buy/watch; no BTC/stables), "
                "recommendation_reason (max 22 words), urgency_score (number), confidence (0..1). "
                "Only recommend altcoins directly supported by the narrative; use [] when bias is bearish or evidence is weak.\n"
                f"Headlines:\n{json.dumps(rows, ensure_ascii=True)}"
            ),
        },
    ]


def _parse_llm_narratives(raw_text: str, items: list[CryptoNewsItem], *, limit: int) -> list[MarketNarrative]:
    text = (raw_text or "").strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()
    data = json.loads(text)
    if not isinstance(data, list):
        return []
    by_id = {idx: item for idx, item in enumerate(items[:12], start=1)}
    narratives: list[MarketNarrative] = []
    for row in data[:limit]:
        if not isinstance(row, dict):
            continue
        title = _clean_text(row.get("title"))
        explanation = _clean_text(row.get("explanation"))
        if not title or not explanation:
            continue
        bias = str(row.get("bias", "mixed") or "mixed").lower()
        if bias not in {"bullish", "bearish", "mixed"}:
            bias = "mixed"
        evidence_ids = row.get("evidence_ids") or []
        evidence: list[str] = []
        if isinstance(evidence_ids, list):
            for evidence_id in evidence_ids[:3]:
                try:
                    item = by_id.get(int(evidence_id))
                except Exception:
                    item = None
                if item is not None:
                    evidence.append(_headline_text(item))
        raw_recs = row.get("recommended_altcoins") or []
        recommended: list[str] = []
        if isinstance(raw_recs, list):
            for coin in raw_recs[:5]:
                ticker = re.sub(r"[^A-Z0-9]", "", str(coin or "").upper())
                if ticker and ticker not in {"BTC", "USDT", "USDC", "DAI"} and ticker not in recommended:
                    recommended.append(ticker)
        rec_reason = _clean_text(row.get("recommendation_reason"))[:180]
        narratives.append(
            MarketNarrative(
                title=title[:80],
                bias=bias,
                explanation=explanation[:240],
                evidence=tuple(evidence),
                recommended_altcoins=tuple(recommended),
                recommendation_reason=rec_reason,
                source="llm",
                urgency_score=round(float(row.get("urgency_score", 0.0) or 0.0), 3),
                confidence=round(max(0.0, min(1.0, float(row.get("confidence", 0.0) or 0.0))), 3),
            )
        )
    return narratives


async def build_market_hot_narratives(
    cfg: dict,
    items: list[CryptoNewsItem],
    *,
    limit: int = 5,
) -> list[MarketNarrative]:
    """Build Telegram-ready market narratives, using an LLM when configured."""
    if not items or limit <= 0:
        return []
    fallback = build_rule_based_market_narratives(items, limit=limit)
    llm_candidates = _llm_provider_candidates(cfg)
    if not llm_candidates:
        return fallback

    for llm in llm_candidates:
        provider = str(llm.get("provider", "llm") or "llm")
        try:
            payload = {
                "model": llm["model"],
                "messages": _llm_prompt(items, limit=limit),
                "temperature": 0.2,
                "max_tokens": 900,
            }
            if provider == "gemini":
                # Gemini 2.5 can spend output budget on hidden thinking in the
                # OpenAI-compatible API. Disable reasoning for this short JSON
                # clustering task so the response does not truncate mid-array.
                payload["reasoning_effort"] = "none"
                payload["max_tokens"] = 1800
            headers = {"Authorization": f"Bearer {llm['api_key']}", "Content-Type": "application/json"}
            async with httpx.AsyncClient(timeout=llm["timeout"], headers=headers) as client:
                resp = await client.post(llm["api_url"], json=payload)
            if resp.status_code >= 400:
                log.debug("Crypto narrative LLM provider=%s failed: HTTP %s", provider, resp.status_code)
                continue
            body = resp.json()
            content = (((body.get("choices") or [{}])[0].get("message") or {}).get("content") or "").strip()
            narratives = _parse_llm_narratives(content, items, limit=limit)
            if narratives:
                return [
                    MarketNarrative(
                        title=n.title,
                        bias=n.bias,
                        explanation=n.explanation,
                        evidence=n.evidence,
                        recommended_altcoins=n.recommended_altcoins,
                        recommendation_reason=n.recommendation_reason,
                        source=f"llm:{provider}",
                        urgency_score=n.urgency_score,
                        confidence=n.confidence,
                    )
                    for n in narratives
                ]
        except Exception as exc:
            log.debug("Crypto narrative LLM provider=%s failed: %s", provider, exc)
            continue
    return fallback

